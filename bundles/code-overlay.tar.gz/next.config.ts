import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  poweredByHeader: false,
  outputFileTracingIncludes: {
    "/*": ["./assets/posters/originals/**/*"]
  },
  experimental: {
    serverActions: { bodySizeLimit: "20mb" }
  }
};

export default nextConfig;
