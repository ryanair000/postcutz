import { readFile } from "node:fs/promises";
import { join } from "node:path";
import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";
import { createAdminClient } from "@/lib/supabase/admin";
import { PORTAL } from "@/lib/portal";

function safeName(value: string) {
  return value.replace(/[^a-zA-Z0-9._-]/g, "-");
}

async function prepare(id: string) {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return { error: "Sign in required.", status: 401 } as const;

  const { data: unlock } = await supabase.from(PORTAL.unlocks).select("id").eq("user_id", user.id).eq("poster_id", id).maybeSingle();
  if (!unlock) return { error: "Unlock this poster before downloading it.", status: 403 } as const;

  const { data: poster, error } = await supabase.from(PORTAL.posters)
    .select("slug, original_path, source_type, file_name, mime_type")
    .eq("id", id)
    .single();
  if (error || !poster) return { error: "The poster file is not available yet.", status: 404 } as const;

  await supabase.rpc("poster_portal_record_download", { p_poster_id: id });

  if (poster.source_type === "builtin") {
    try {
      const fileName = `${safeName(poster.slug)}.webp`;
      const bytes = await readFile(join(process.cwd(), "public", "posters", "previews", fileName));
      return { bytes, fileName, contentType: "image/webp" } as const;
    } catch {
      return { error: "The poster file could not be prepared.", status: 500 } as const;
    }
  }

  if (!poster.original_path) return { error: "The original file is not available yet.", status: 404 } as const;
  const admin = createAdminClient();
  const downloadName = safeName(poster.file_name || `${poster.slug}.png`);
  const { data: signed, error: signError } = await admin.storage.from(PORTAL.originalBucket)
    .createSignedUrl(poster.original_path, 120, { download: downloadName });
  if (signError || !signed?.signedUrl) return { error: "Could not prepare the secure download.", status: 500 } as const;
  return { url: signed.signedUrl, fileName: downloadName } as const;
}

export async function POST(_: Request, { params }: { params: Promise<{ id: string }> }) {
  const result = await prepare((await params).id);
  if ("error" in result) return NextResponse.json({ error: result.error }, { status: result.status });
  if ("bytes" in result) {
    const dataUrl = `data:${result.contentType};base64,${result.bytes.toString("base64")}`;
    return NextResponse.json({ url: dataUrl, file_name: result.fileName });
  }
  return NextResponse.json({ url: result.url, file_name: result.fileName });
}

export async function GET(_: Request, { params }: { params: Promise<{ id: string }> }) {
  const result = await prepare((await params).id);
  if ("error" in result) return NextResponse.json({ error: result.error }, { status: result.status });
  if ("bytes" in result) {
    return new Response(result.bytes, {
      headers: {
        "Content-Type": result.contentType,
        "Content-Disposition": `attachment; filename="${result.fileName}"`,
        "Cache-Control": "private, no-store"
      }
    });
  }
  return NextResponse.redirect(result.url);
}
